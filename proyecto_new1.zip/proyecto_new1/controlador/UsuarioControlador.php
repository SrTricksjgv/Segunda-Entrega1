<?php
session_start();
require_once __DIR__ . '/../modelo/Usuario.php';

header('Content-Type: application/json');

$usuarioModel = new Usuario();

function loginUsuario($usuario, $password) {
    global $usuarioModel;
    $usuarioData = $usuarioModel->verificarCredenciales($usuario, $password);
    if ($usuarioData) {
        $_SESSION['usuario'] = $usuario;
        $_SESSION['tipo_usuario'] = $usuarioData['tipo_usuario'];
        return [
            'success' => true,
            'tipo_usuario' => $usuarioData['tipo_usuario'],
            'mensaje' => 'Ingreso exitoso'
        ];
    } else {
        return [
            'success' => false,
            'tipo_usuario' => null,
            'mensaje' => 'Usuario o contraseña incorrectos'
        ];
    }
}

function registrarUsuario($username, $password, $tipo_usuario) {
    global $usuarioModel;
    $passwordHash = password_hash($password, PASSWORD_BCRYPT);
    if ($usuarioModel->insertar($username, $passwordHash, $tipo_usuario)) {
        return [
            'success' => true,
            'mensaje' => 'Usuario registrado con éxito'
        ];
    } else {
        return [
            'success' => false,
            'mensaje' => 'Error al registrar usuario'
        ];
    }
}

function listarUsuarios() {
    global $usuarioModel;
    return $usuarioModel->listar();
}

function eliminarUsuario($nombre) {
    global $usuarioModel;
    if ($usuarioModel->eliminar($nombre)) {
        return [
            'success' => true,
            'mensaje' => 'Usuario eliminado'
        ];
    } else {
        return [
            'success' => false,
            'mensaje' => 'Error al eliminar'
        ];
    }
}

function modificarUsuario($nombre, $nuevoNombre, $nuevoTipoUsuario, $nuevaPassword = '') {
    global $usuarioModel;
    if ($nuevaPassword) {
        $ok = $usuarioModel->modificar($nombre, $nuevoNombre, $nuevoTipoUsuario, $nuevaPassword);
    } else {
        $ok = $usuarioModel->modificar($nombre, $nuevoNombre, $nuevoTipoUsuario);
    }
    if ($ok) {
        return [
            'success' => true,
            'mensaje' => 'Usuario actualizado'
        ];
    } else {
        return [
            'success' => false,
            'mensaje' => 'Error al actualizar'
        ];
    }
}

$accion = $_POST['accion'] ?? $_GET['accion'] ?? '';

if ($accion === 'login') {
    // LOGIN
    $usuario = $_POST['usuario'] ?? '';
    $password = $_POST['password'] ?? '';

    $resultado = loginUsuario($usuario, $password);
    echo json_encode($resultado);
} elseif ($accion === 'registro') {
    // REGISTRO
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $tipo_usuario = $_POST['tipo_usuario'] ?? 'cliente'; // Por defecto 'cliente'

    if ($username && $password) {
        $resultado = registrarUsuario($username, $password, $tipo_usuario);
        echo json_encode($resultado);
    } else {
        echo json_encode([
            'success' => false,
            'mensaje' => 'Por favor, complete todos los campos'
        ]);
    }
} elseif ($accion === 'listar_json') {
    // LISTAR USUARIOS
    $usuarios = listarUsuarios();
    // Devuelve usuario y tipo_usuario
    echo json_encode($usuarios);
} elseif ($accion === 'eliminar') {
    // ELIMINAR USUARIO CLIENTE
    $nombre = $_POST['nombre'] ?? '';
    $resultado = eliminarUsuario($nombre);
    echo json_encode($resultado);
} elseif ($accion === 'modificar') {
    $nombre = $_POST['nombre'] ?? '';
    $nuevoNombre = $_POST['nuevoNombre'] ?? '';
    $nuevoTipoUsuario = $_POST['nuevoTipoUsuario'] ?? 'cliente';
    $nuevaPassword = $_POST['nuevaPassword'] ?? '';

    $resultado = modificarUsuario($nombre, $nuevoNombre, $nuevoTipoUsuario, $nuevaPassword);
    echo json_encode($resultado);
} else {
    echo json_encode([
        'success' => false,
        'mensaje' => 'Acción no válida'
    ]);
}
?>
